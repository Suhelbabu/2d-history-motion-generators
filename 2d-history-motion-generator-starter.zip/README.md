# 2D History Motion Graphics Generator (starter)

This is a starter Remotion project for vertical 2D-style history shorts. It includes five animated sample scenes with text, gradients, floating particles, zoom, and fades.

## Important
This is a starter template, not a complete automatic text-to-video AI. To make new videos, edit the `scenes` array in `src/HistoryShort.tsx`. Add original/licensed images, narration, and scene-specific animation as the project grows.

## Run locally or in a supported cloud development environment
1. Install Node.js (20+ recommended).
2. Run `npm install`.
3. Preview with `npm run dev`.
4. Render MP4 with `npm run render`.

Output: `out/history-short.mp4`

## Mobile-only note
A phone browser alone generally cannot render this project locally. Use a cloud development environment that supports Node.js and Remotion rendering, or a computer. GitHub stores the project but does not render the video by itself.
