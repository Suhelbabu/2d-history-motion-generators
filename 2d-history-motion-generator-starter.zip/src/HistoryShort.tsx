import React from 'react';
import { AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig } from 'remotion';

const scenes = [
  { title: 'THE INCA EMPIRE', subtitle: 'A kingdom built in the Andes', color: '#6b2d1c', symbol: '☀' },
  { title: 'NOT JUST GOLD', subtitle: 'Their real power was organization', color: '#8b4b26', symbol: '◆' },
  { title: 'ROADS THROUGH THE MOUNTAINS', subtitle: 'Thousands of miles connected the empire', color: '#354a43', symbol: '⌁' },
  { title: 'TERRACES OF LIFE', subtitle: 'Farmers turned steep slopes into fields', color: '#76552d', symbol: '▤' },
  { title: 'POWER WITHOUT COINS', subtitle: 'Labor and storehouses supported the state', color: '#3b3c58', symbol: '✦' },
];

export const HistoryShort: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const sceneFrames = 6 * fps;
  const sceneIndex = Math.min(scenes.length - 1, Math.floor(frame / sceneFrames));
  const scene = scenes[sceneIndex];
  const local = frame - sceneIndex * sceneFrames;
  const opacity = interpolate(local, [0, 12, sceneFrames - 12, sceneFrames], [0, 1, 1, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const zoom = interpolate(local, [0, sceneFrames], [1.04, 1.14]);
  const floatY = Math.sin(frame / 12) * 10;

  return (
    <AbsoluteFill style={{ backgroundColor: scene.color, color: '#fff2d4', fontFamily: 'Georgia, serif', overflow: 'hidden' }}>
      <AbsoluteFill style={{ transform: `scale(${zoom})`, opacity: 0.24 }}>
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 50% 35%, #f4c46b 0%, transparent 38%)' }} />
        {Array.from({ length: 22 }).map((_, i) => (
          <div key={i} style={{
            position: 'absolute', left: `${(i * 37) % 100}%`, top: `${(i * 61) % 100}%`,
            width: 4 + (i % 4) * 2, height: 4 + (i % 4) * 2, borderRadius: 99,
            backgroundColor: '#ffd98a', opacity: 0.35 + (i % 5) * 0.12,
            transform: `translateY(${Math.sin(frame / 10 + i) * 28}px)`
          }} />
        ))}
      </AbsoluteFill>
      <div style={{ position: 'absolute', inset: 48, border: '2px solid rgba(255,224,164,.65)', borderRadius: 34 }} />
      <div style={{ position: 'absolute', top: 150, left: 90, right: 90, textAlign: 'center', fontSize: 25, letterSpacing: 7, color: '#f5ce7b' }}>
        HISTORY • IN 60 SECONDS
      </div>
      <div style={{ position: 'absolute', top: 390, left: 70, right: 70, textAlign: 'center', transform: `translateY(${floatY}px)`, opacity }}>
        <div style={{ fontSize: 150, color: '#ffd57b', textShadow: '0 0 45px rgba(255,191,77,.5)', marginBottom: 42 }}>{scene.symbol}</div>
        <div style={{ fontSize: 76, lineHeight: 1.08, fontWeight: 800, textTransform: 'uppercase', textShadow: '0 5px 25px rgba(0,0,0,.35)' }}>{scene.title}</div>
        <div style={{ height: 4, width: 210, margin: '40px auto', backgroundColor: '#f5ce7b' }} />
        <div style={{ fontSize: 38, lineHeight: 1.35, fontFamily: 'Arial, sans-serif', color: '#fff7e7' }}>{scene.subtitle}</div>
      </div>
      <div style={{ position: 'absolute', bottom: 150, left: 90, right: 90, textAlign: 'center', fontSize: 23, letterSpacing: 4, color: '#f5ce7b' }}>
        2D HISTORY MOTION GRAPHICS
      </div>
    </AbsoluteFill>
  );
};
