import React from 'react';
import { Composition } from 'remotion';
import { HistoryShort } from './HistoryShort';

export const RemotionRoot: React.FC = () => (
  <>
    <Composition
      id="Main"
      component={HistoryShort}
      durationInFrames={30 * 30}
      fps={30}
      width={1080}
      height={1920}
    />
  </>
);
